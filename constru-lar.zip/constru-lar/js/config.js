// Configurações centrais da CONSTRU LAR — edite aqui.
window.CONFIG = {
  empresa: "CONSTRU LAR",
  whatsapp: "5511967301933",
  whatsappExibicao: "+55 11 96730-1933",
  instagram: "https://www.instagram.com/constru.lar?obrf=MTloNzJocWhjeWYyeQ%3D%3D",
  // {produto} é substituído pelo nome do produto
  mensagemOrcamento: "Olá! Gostaria de solicitar um orçamento para o produto: {produto}.",
  mensagemGeral: "Olá! Vim pelo site da CONSTRU LAR e gostaria de fazer um pedido."
};
