(() => {
  const C = window.CONFIG, P = window.PRODUCTS, CATS = window.CATEGORIAS;
  const $ = s => document.querySelector(s);
  const wa = t => `https://wa.me/${C.whatsapp}?text=${encodeURIComponent(t)}`;
  const brl = v => v == null ? "Consulte" : v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  const norm = s => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const icone = id => (CATS.find(c => c.id === id) || {}).icone || "🏗️";
  const state = { cat: "todos", q: "" };

  document.querySelectorAll("[data-wa]").forEach(a => { a.href = wa(C.mensagemGeral); a.target = "_blank"; a.rel = "noopener"; });
  document.querySelectorAll("[data-ig]").forEach(a => { a.href = C.instagram; a.target = "_blank"; a.rel = "noopener noreferrer"; });
  document.querySelectorAll("[data-wa-text]").forEach(e => e.textContent = C.whatsappExibicao);

  // Se o arquivo do logotipo ainda não estiver na pasta, mostra um marcador discreto
  document.querySelectorAll(".logo-img").forEach(img => img.addEventListener("error", () => {
    img.replaceWith(Object.assign(document.createElement("span"), { className: "logo-fallback", textContent: "CL" }));
  }));

  const card = p => {
    const img = p.imagem
      ? `<img src="${p.imagem}" alt="${p.nome}" loading="lazy" width="400" height="400">`
      : `<span class="ph" aria-hidden="true">${icone(p.categoria)}</span>`;
    const selo = p.selo ? `<span class="selo ${p.selo === "OFERTA" ? "red" : ""}">${p.selo}</span>` : "";
    const cat = (CATS.find(c => c.id === p.categoria) || {}).nome || "";
    return `<article class="card"><div class="thumb">${selo}${img}</div>
      <div class="body"><small>${cat}</small><h3>${p.nome}</h3><p>${p.descricao}</p>
      <div class="price">${brl(p.preco)}</div>
      <a class="btn btn-red" target="_blank" rel="noopener" href="${wa(C.mensagemOrcamento.replace("{produto}", p.nome))}">Solicitar orçamento</a></div></article>`;
  };

  const chips = $("#chips");
  chips.innerHTML = [{ id: "todos", nome: "Todos os produtos" }, ...CATS]
    .map(c => `<button class="chip" data-cat="${c.id}" aria-pressed="${c.id === "todos"}">${c.icone ? c.icone + " " : ""}${c.nome}</button>`).join("");
  chips.addEventListener("click", e => { const b = e.target.closest("[data-cat]"); if (b) { state.cat = b.dataset.cat; render(true); } });
  $("#busca").addEventListener("input", e => { state.q = e.target.value; render(true); });
  $("#limpar").addEventListener("click", () => { state.cat = "todos"; state.q = ""; $("#busca").value = ""; render(true); });

  function render(pulse) {
    chips.querySelectorAll(".chip").forEach(b => b.setAttribute("aria-pressed", b.dataset.cat === state.cat));
    const q = norm(state.q.trim());
    const list = P.filter(p => (state.cat === "todos" || p.categoria === state.cat) && (!q || norm(p.nome + " " + p.descricao).includes(q)));
    const grid = $("#grid");
    grid.innerHTML = list.map(card).join("");
    $("#vazio").hidden = list.length > 0;
    $("#contador").textContent = `${list.length} ${list.length === 1 ? "produto encontrado" : "produtos encontrados"}`;
    if (pulse) { grid.classList.remove("flash"); void grid.offsetWidth; grid.classList.add("flash"); }
  }
  render();
  $("#ofertas-grid").innerHTML = P.filter(p => p.selo).slice(0, 8).map(card).join("");

  const nav = $("#nav"), btn = $("#menu-btn");
  btn.addEventListener("click", () => btn.setAttribute("aria-expanded", nav.classList.toggle("open")));
  nav.addEventListener("click", e => { if (e.target.closest("a")) { nav.classList.remove("open"); btn.setAttribute("aria-expanded", false); } });
  const header = $("header");
  const onScroll = () => header.classList.toggle("scrolled", scrollY > 20);
  addEventListener("scroll", onScroll, { passive: true }); onScroll();

  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .1 });
  document.querySelectorAll(".reveal").forEach(el => io.observe(el));
  $("#ano").textContent = new Date().getFullYear();
})();
