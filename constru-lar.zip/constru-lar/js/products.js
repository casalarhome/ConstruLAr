/* Catálogo de produtos. DADOS DEMONSTRATIVOS: nomes, descrições e preços são exemplos
   e devem ser substituídos pelos reais. Campos: id, nome, categoria, descricao,
   preco (número ou null = "Consulte"), imagem ("assets/products/arquivo.jpg" ou ""
   para usar o ícone da categoria), selo ("OFERTA" | "DESTAQUE" | "MAIS PROCURADO" ou ""). */
window.CATEGORIAS = [
  { id: "cimento", nome: "Cimento e argamassa", icone: "🧱" },
  { id: "areia", nome: "Areia e pedra", icone: "⛰️" },
  { id: "hidraulico", nome: "Materiais hidráulicos", icone: "🚰" },
  { id: "eletrico", nome: "Materiais elétricos", icone: "💡" },
  { id: "ferramentas", nome: "Ferramentas", icone: "🔨" },
  { id: "chuveiros", nome: "Chuveiros e acessórios", icone: "🚿" },
  { id: "tubos", nome: "Tubos e conexões", icone: "🔧" },
  { id: "acabamento", nome: "Materiais para acabamento", icone: "🎨" }
];
window.PRODUCTS = [
  { id: 1, nome: "Cimento 50 kg", categoria: "cimento", descricao: "Cimento Portland para obras em geral.", preco: 38.9, imagem: "", selo: "MAIS PROCURADO" },
  { id: 2, nome: "Argamassa AC-I 20 kg", categoria: "cimento", descricao: "Para assentamento de pisos internos.", preco: 18.5, imagem: "", selo: "" },
  { id: 3, nome: "Argamassa AC-III 20 kg", categoria: "cimento", descricao: "Alta aderência para áreas externas.", preco: 29.9, imagem: "", selo: "OFERTA" },
  { id: 4, nome: "Rejunte 1 kg", categoria: "cimento", descricao: "Rejunte flexível para pisos e azulejos.", preco: 9.9, imagem: "", selo: "" },
  { id: 5, nome: "Areia média (saco)", categoria: "areia", descricao: "Areia lavada para reboco e concreto.", preco: 12.0, imagem: "", selo: "" },
  { id: 6, nome: "Areia fina (saco)", categoria: "areia", descricao: "Ideal para acabamentos e massa fina.", preco: 12.0, imagem: "", selo: "" },
  { id: 7, nome: "Pedra brita 1 (saco)", categoria: "areia", descricao: "Brita para concreto estrutural.", preco: 14.0, imagem: "", selo: "DESTAQUE" },
  { id: 8, nome: "Torneira de jardim", categoria: "hidraulico", descricao: "Torneira metálica com bico para mangueira.", preco: 24.9, imagem: "", selo: "" },
  { id: 9, nome: "Registro de gaveta 3/4\"", categoria: "hidraulico", descricao: "Registro com acabamento cromado.", preco: 39.9, imagem: "", selo: "" },
  { id: 10, nome: "Caixa d'água 500 L", categoria: "hidraulico", descricao: "Polietileno com tampa rosqueável.", preco: 389.0, imagem: "", selo: "DESTAQUE" },
  { id: 11, nome: "Fita veda rosca 18 mm", categoria: "hidraulico", descricao: "Vedação para conexões roscáveis.", preco: 5.5, imagem: "", selo: "" },
  { id: 12, nome: "Fio flexível 2,5 mm (rolo 100 m)", categoria: "eletrico", descricao: "Cabo para instalações residenciais.", preco: 219.0, imagem: "", selo: "" },
  { id: 13, nome: "Disjuntor 20 A", categoria: "eletrico", descricao: "Disjuntor unipolar para quadro de luz.", preco: 14.9, imagem: "", selo: "" },
  { id: 14, nome: "Tomada 10 A com placa", categoria: "eletrico", descricao: "Conjunto tomada e espelho.", preco: 11.9, imagem: "", selo: "MAIS PROCURADO" },
  { id: 15, nome: "Lâmpada LED 9 W", categoria: "eletrico", descricao: "Luz branca, baixo consumo.", preco: 8.9, imagem: "", selo: "OFERTA" },
  { id: 16, nome: "Martelo de unha 27 mm", categoria: "ferramentas", descricao: "Cabo reforçado, cabeça forjada.", preco: 32.9, imagem: "", selo: "" },
  { id: 17, nome: "Trena 5 m", categoria: "ferramentas", descricao: "Fita emborrachada com trava.", preco: 19.9, imagem: "", selo: "" },
  { id: 18, nome: "Colher de pedreiro", categoria: "ferramentas", descricao: "Lâmina de aço, cabo de madeira.", preco: 21.9, imagem: "", selo: "" },
  { id: 19, nome: "Chave de fenda e Phillips (kit)", categoria: "ferramentas", descricao: "Kit com 6 peças.", preco: 27.9, imagem: "", selo: "OFERTA" },
  { id: 20, nome: "Chuveiro elétrico 5500 W", categoria: "chuveiros", descricao: "Quatro temperaturas, 220 V.", preco: 69.9, imagem: "", selo: "MAIS PROCURADO" },
  { id: 21, nome: "Ducha higiênica com registro", categoria: "chuveiros", descricao: "Acabamento cromado.", preco: 79.0, imagem: "", selo: "" },
  { id: 22, nome: "Cano PVC 100 mm (barra 6 m)", categoria: "tubos", descricao: "Tubo para esgoto residencial.", preco: 94.0, imagem: "", selo: "" },
  { id: 23, nome: "Cano PVC soldável 25 mm (barra 6 m)", categoria: "tubos", descricao: "Tubo para água fria.", preco: 32.0, imagem: "", selo: "DESTAQUE" },
  { id: 24, nome: "Joelho PVC 90° 25 mm", categoria: "tubos", descricao: "Conexão soldável.", preco: 1.9, imagem: "", selo: "" },
  { id: 25, nome: "Tinta acrílica branca 18 L", categoria: "acabamento", descricao: "Cobertura alta para paredes.", preco: 249.0, imagem: "", selo: "OFERTA" },
  { id: 26, nome: "Rolo de lã 23 cm", categoria: "acabamento", descricao: "Para tintas acrílicas e látex.", preco: 15.9, imagem: "", selo: "" },
  { id: 27, nome: "Massa corrida 5 kg", categoria: "acabamento", descricao: "Nivela e prepara paredes internas.", preco: 36.9, imagem: "", selo: "" },
  { id: 28, nome: "Silicone incolor 280 g", categoria: "acabamento", descricao: "Vedação para vidros e esquadrias.", preco: 17.9, imagem: "", selo: "" }
];
